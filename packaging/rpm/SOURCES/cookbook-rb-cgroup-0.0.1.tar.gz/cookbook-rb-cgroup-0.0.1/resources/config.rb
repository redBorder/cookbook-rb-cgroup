#Cookbook Name :: rbaioutliers
#
# Resource:: config
#

actions :add, :remove
default_action :add
