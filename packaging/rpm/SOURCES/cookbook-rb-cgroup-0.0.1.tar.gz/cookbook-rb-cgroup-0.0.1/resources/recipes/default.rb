#
# Cookbook Name:: rbcgroup
# Recipe:: default
#
# redborder
#
#

rbcgroup_config "config" do
  action :add
end
