name             'rbcgroup'
maintainer       'redborder'
maintainer_email 'malvarez@redborder.com'
license          'AGPL 3.0'
description      'Installs/Configures cookbook-rb-cgroup'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.0.2'
